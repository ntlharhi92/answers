=import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

//@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/java/Feature"
        ,glue={"src/test/java"}
)


public class   CucumberRunner {
}
