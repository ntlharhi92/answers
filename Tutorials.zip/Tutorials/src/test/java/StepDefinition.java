import cucumber.api.CucumberOptions;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import za.co.baloyi.DriverFactory;


public class StepDefinition {


    @Test

    WebDriver driver = null;

    @Given("^Open the chrome and launch the application$")
    public void openTheChromeAndLaunchTheApplication() {
        driver = DriverFactory.initializeDriver();
    }

    @When("^Enter the Username \"([^\"]*)\" and Password \"([^\"]*)\"$")
    public void enterTheUsernameAndPassword(String arg0, String arg1) throws Throwable {
                driver.findElement(By.xpath(//*[@id="user-name"]).sendKeys(username));
                driver.findElement(By.xpath(//*[@id="password"]).sendKeys(password));
                        driver.findElement(By.xpath(//*[@id="login-button"]).click;
    }

    @Then("^Add 2 products to your shopping cart$")
    public void Add2ProductToYourShopping() {
        driver.findElement(By.xpath(//*[@id="add-to-cart-sauce-labs-backpack"]).click;
                driver.findElement(By.xpath(//*[@id="add-to-cart-sauce-labs-bike-light"]).click

    }

    @Given("^Confirm that the correct products are added to your cart$")
    public void Confirmthatthecorrectproductsareaddedtoyourcart() {
        driver.findElement(By.xpath(//*[@id="shopping_cart_container"]/a/span).click
    }
    @When("^Add your information (first name, last name and postal code)$")
    public void AddYourInformation() {

    }
    @Then("^checkout$")
    public void Finishyourorder$() {
    }
      driver.findElement(By.xpath(//*[@id="checkout"]).click
    }


