package za.co.baloyi;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

public class LoadConfigs {

    private static String result = "";
    private static InputStream input = null;
    private static Properties prop = null;

    public static Properties getPropValues() {

        try {
            prop = new Properties();
            String propFileName = "config.properties";

            input = LoadConfigs.class.getClassLoader().getResourceAsStream(propFileName);

            if (input != null) {
                prop.load(input);
            } else {
                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
            }

            Date time = new Date(System.currentTimeMillis());

            // get the property value and print it out
            String user = prop.getProperty("user");

            //result = "Company List = " + company1 + ", " + company2 + ", " + company3;
            //System.out.println(result + "\nProgram Ran on " + time + " by user=" + user);
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            try {
                input.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return prop;
    }

}

