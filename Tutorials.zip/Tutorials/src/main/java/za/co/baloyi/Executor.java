package za.co.baloyi;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openga.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;


public class Executor {

    private static WebDriver driver=null;


   private static void InitializeDriver()
   {
       System.setProperty("webdriver.chrome.driver", "./src/ChromeDrivers/chromedriver.exe");
       // Initialize browser
       WebDriver driver = new ChromeDriver();
       driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
       driver.manage().window().maximize();
   }


   public static void NavigateTo(String url)
   {
       try
       {
           InitializeDriver();
           driver.get(url);
       }
       catch (Exception e)
       {

       }
   }



    private static String GetXpath(String object)
    {
        try
        {
            String filePath = "test.txt";
            HashMap<String, String> map = new HashMap<String, String>();

            String line;mvm
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            while ((line = reader.readLine()) != null)
            {
                String[] parts = line.split("|", 2);
                if (parts.length >= 2)
                {
                    String key = parts[0];
                    String value = parts[1];
                    map.put(key, value);
                } else {
                    System.out.println("ignoring line: " + line);
                }
            }

            for (String key : map.keySet())
            {
                System.out.println(key + ":" + map.get(key));
            }
            reader.close();
        }
        catch (Exception e)
        {
            return "";
        }  return null;
    }

    public static void Click(String object)
    {
        try
        {
            String xpath = GetXpath(object);
            WebElement element = driver.findElement(By.xpath((xpath)));
            int counter =0;
            while(!element.isDisplayed())
            {
                if(counter>100 || element.isDisplayed())
                {
                    break;
                }
                counter++;
                driver.wait(200);
                element = driver.findElement(By.xpath((xpath)));
            }
            if(element.isDisplayed())
            {
                element.click();
            }
        }
        catch (Exception e)
        {

        }
    }


    public static void ClearAndType(String object,String value)
    {
        try
        {
            String xpath = GetXpath(object);
            WebElement element = driver.findElement(By.xpath((xpath)));
            int counter =0;
            while(!element.isDisplayed())
            {
                if(counter>100 || element.isDisplayed())
                {
                    break;
                }
                counter++;
                driver.wait(200);
                element = driver.findElement(By.xpath((xpath)));
            }
            if(element.isDisplayed())
            {
                element.sendKeys(value);
            }
        }
        catch (Exception e)
        {

        }
    }



}
