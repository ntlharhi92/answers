package za.co.baloyi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
mvn
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class DriverFactory {
    public static WebDriver driver = null;

    public static WebDriver initializeDriver() {


       System.setProperty("webdriver.chrome.driver", LoadConfigs.getPropValues().getProperty("driverpath"));
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        driver.get(LoadConfigs.getPropValues().getProperty("url"));

        return driver;

        //driver.findElement(By.ByClassName'menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-11 current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-25 et_first_mobile_item')

    }
}
